"""Stable native submission and local transport interface."""
from importlib import import_module

__all__ = [
    'NativeSender', 'NativeImageDownloader', 'NativeError', 'CHAT_ID',
    'REQUEST_ID', 'MAX_FRAME', 'encode', 'decode', 'receive', 'request',
    'text_parts', 'validate_send', 'IMAGE_DOWNLOAD_ERRORS',
]


def __getattr__(name):
    if name == 'NativeError':
        from adapter_wc.errors import NativeError
        return NativeError
    if name == 'NativeSender':
        from adapter_wc.native.sender import NativeSender
        return NativeSender
    if name == 'NativeImageDownloader':
        from adapter_wc.native.image_download import NativeImageDownloader
        return NativeImageDownloader
    if name == 'IMAGE_DOWNLOAD_ERRORS':
        from adapter_wc.native.image_contract import ERRORS
        return ERRORS
    if name in __all__:
        return getattr(import_module('adapter_wc.native.protocol'), name)
    raise AttributeError(name)
