"""Stable runtime path and locking primitives."""
from importlib import import_module

__all__ = ['file_lock', 'require_private_directory']


def __getattr__(name):
    module = {'file_lock': 'locking', 'require_private_directory': 'paths'}.get(name)
    if module is None:
        raise AttributeError(name)
    return getattr(import_module('adapter_wc.runtime.' + module), name)
