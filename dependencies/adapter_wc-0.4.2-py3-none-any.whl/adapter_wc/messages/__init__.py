"""Stable message classification operations for adapter consumers."""
from importlib import import_module

__all__ = ['is_pat', 'parse_pat', 'parse_quoted_reply', 'image_md5', 'local_image_cache_key']


def __getattr__(name):
    if name in ('is_pat', 'parse_pat'):
        return getattr(import_module('adapter_wc.messages.pats'), name)
    if name in __all__:
        return getattr(import_module('adapter_wc.messages.references'), name)
    raise AttributeError(name)
