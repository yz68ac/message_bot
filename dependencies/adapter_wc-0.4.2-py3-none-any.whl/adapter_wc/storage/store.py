"""读取微信本地数据库。

- 定位当前账号的 db_storage
- 按需解密 session.db / contact.db / message_*.db（带 WAL patch）
- 解析群聊消息与发送者昵称
"""
from __future__ import annotations

import glob
import hashlib
import json
import logging
import os
import re
import shutil
import sqlite3
import subprocess
import time
import tempfile
import xml.etree.ElementTree as ET
from datetime import datetime
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from adapter_wc.storage import crypto
from adapter_wc.storage.keyscan import find_wechat_pids
from adapter_wc.runtime.paths import require_private_directory
from adapter_wc.runtime.locking import file_lock
from adapter_wc.messages.references import image_md5, local_image_cache_key, parse_quoted_reply
from adapter_wc.messages.pats import parse_pat

from adapter_wc.errors import StoreError


@dataclass(frozen=True)
class HistoryPage:
    messages: list[dict[str, Any]]
    scanned: int
    cursor: tuple[int, int] | None


def _image_paths(bucket: str, month: str, chat_hash: str, stem: str) -> list[dict]:
    base = f"msg/attach/{bucket}/{month}/Img/"
    return [dict(relative=relative, quality=quality) for relative, quality in (
        (base+stem+"_h.dat", "original"), (base+stem+".dat", "cached"),
        (f"cache/{month}/Message/{chat_hash}/Bubble/{stem}_b.dat", "preview"),
        (base+stem+"_t.dat", "thumbnail"))]


def _verified_image_paths(account_root: Path, chat_hash: str, cache_key: str) -> list[dict]:
    """Find month containers in this group only; filenames come from the original message."""
    root = account_root.resolve()

    def safe_directory(path):
        if not path.is_dir() or not path.resolve().is_relative_to(root):
            return False
        return not any(part.is_symlink() for part in (path, *path.parents) if part.is_relative_to(root))

    months = set()
    for base, tail in ((root/"msg/attach"/chat_hash, Path("Img")),
                       (root/"cache", Path("Message")/chat_hash/"Bubble")):
        if not safe_directory(base):
            continue
        for month in base.iterdir():
            if re.fullmatch(r"20[0-9]{2}-(?:0[1-9]|1[0-2])", month.name) and safe_directory(month/tail):
                months.add(month.name)
    # Prefer higher quality across all months, including forwarded/older cached pictures.
    candidates = [item for month in sorted(months, reverse=True)
                  for item in _image_paths(chat_hash, month, chat_hash, cache_key)
                  if safe_directory((root/item["relative"]).parent)]
    priority = {"original": 0, "cached": 1, "preview": 2, "thumbnail": 3}
    return sorted(candidates, key=lambda item: priority[item["quality"]])


def parse_mentioned_users(source: str) -> list[str] | None:
    if not source.strip():
        return None
    try:
        root = ET.fromstring(source)
    except ET.ParseError:
        return None
    users = []
    for node in root.iter():
        if node.tag.rsplit('}', 1)[-1] == 'atuserlist':
            users.extend(u.strip() for u in (node.text or '').split(',') if u.strip())
    return users


def _mtime(path: str) -> float:
    try:
        return os.path.getmtime(path)
    except OSError:
        return 0.0


def _readlink(path: str) -> str:
    try:
        return os.path.realpath(os.readlink(path))
    except OSError:
        return ""


def discover_db_dir(preferred: str = "") -> str:
    """定位当前登录账号的 db_storage。"""
    if preferred:
        path = os.path.expanduser(preferred)
        if os.path.isdir(path):
            return path
        raise StoreError(f"配置的 db_dir 不存在：{path}")

    # 优先从微信进程打开的文件里找正在使用的目录
    try:
        for pid, _rss in find_wechat_pids():
            fd_dir = f"/proc/{pid}/fd"
            found: list[str] = []
            try:
                for fd in os.listdir(fd_dir):
                    target = _readlink(os.path.join(fd_dir, fd))
                    if "xwechat_files" in target and "db_storage" in target:
                        # .../<wxid>/db_storage/xxx/yyy.db
                        idx = target.find("db_storage")
                        found.append(target[: idx + len("db_storage")])
            except OSError:
                pass
            if found:
                return os.path.commonpath(found)
    except Exception:
        pass

    home = str(Path.home())
    patterns = [
        os.path.join(home, "Documents", "xwechat_files", "*", "db_storage"),
        os.path.join(home, "xwechat_files", "*", "db_storage"),
        os.path.join(home, "文档", "xwechat_files", "*", "db_storage"),
    ]
    candidates: list[str] = []
    for pattern in patterns:
        candidates.extend(glob.glob(pattern))
    candidates = [c for c in candidates if os.path.isdir(c)]
    if not candidates:
        raise StoreError('database_directory_not_found')
    # 选最近有写入的
    candidates.sort(key=lambda d: _mtime(os.path.join(d, "session", "session.db")), reverse=True)
    return candidates[0]


def _decompress_zstd(data: bytes) -> str | None:
    try:
        import zstandard as zstd  # type: ignore

        return zstd.ZstdDecompressor().decompress(data).decode("utf-8", "replace")
    except Exception:
        pass
    exe = shutil.which("zstd")
    if exe:
        try:
            proc = subprocess.run(
                [exe, "-dc", "-q"], input=data, capture_output=True, timeout=10
            )
            if proc.returncode == 0:
                return proc.stdout.decode("utf-8", "replace")
        except Exception:
            pass
    return None


def _strip_xml_title(text: str) -> str:
    """从 type=49 的 XML 里尽量取标题/内容。"""
    import re

    for tag in ("title", "des", "content"):
        m = re.search(rf"<{tag}>(.*?)</{tag}>", text, re.S)
        if m:
            value = re.sub(r"<!\[CDATA\[(.*?)\]\]>", r"\1", m.group(1), flags=re.S)
            return value.strip()
    return ""


class WeChatStore:
    def __init__(self, db_dir: str, keys_file: str, decrypted_dir: str):
        self.db_dir = discover_db_dir(db_dir)
        self.keys_file = keys_file
        self.decrypted_dir = decrypted_dir
        try:
            require_private_directory(decrypted_dir)
        except (ValueError, OSError) as exc:
            raise StoreError(str(exc)) from exc
        self.keys = self._load_keys()
        self._mtimes: dict[str, tuple[float, float]] = {}
        self._wal_mtimes: dict[str, float] = {}

    # ---------- 基础 ----------
    def _load_keys(self) -> dict[str, Any]:
        path = Path(self.keys_file)
        if not path.exists():
            raise StoreError(
                "database_keys_file_missing"
            )
        data = json.loads(path.read_text(encoding="utf-8"))
        return {k: v for k, v in data.items() if not k.startswith("_")}

    @property
    def self_wxid(self) -> str:
        if hasattr(self, "_account_username"):
            return self._account_username
        name = Path(self.db_dir).parent.name
        if not name.startswith("wxid_"):
            return ""
        contacts = self.contacts()
        # 实测账号目录附带后缀，不能直接当作微信 username。
        candidates = (name, name.rsplit("_", 1)[0])
        self._account_username = next((c for c in candidates if c in contacts), "")
        return self._account_username

    def _key_for(self, rel: str) -> dict[str, Any] | None:
        rel = rel.replace(os.sep, "/")
        keys = self.keys
        for candidate in (rel, rel.replace("/", "\\")):
            if candidate in keys:
                return keys[candidate]
        return None

    def _plain_path(self, rel: str) -> Path:
        path = Path(rel)
        if path.is_absolute() or '..' in path.parts or not path.parts:
            raise StoreError('invalid_database_path')
        root = Path(self.decrypted_dir).resolve()
        target = root / path
        if not target.resolve().is_relative_to(root) or target.is_symlink():
            raise StoreError('invalid_database_path')
        return target

    def refresh(self, rel: str) -> Path:
        """确保 rel 对应的明文数据库是最新的，返回明文路径。"""
        dst = self._plain_path(rel)
        require_private_directory(dst.parent)
        with file_lock(dst.with_name(dst.name + '.lock'), blocking=True):
            return self._refresh(rel, dst)

    def _refresh(self, rel: str, dst: Path) -> Path:
        rel = rel.replace(os.sep, "/")
        src = os.path.join(self.db_dir, rel)
        if not os.path.exists(src):
            raise StoreError(f"数据库不存在：{src}")
        info = self._key_for(rel)
        if not info:
            raise StoreError(
                f"缺少 {rel} 的密钥。请重新运行 scan-keys（注意 db_dir 要对应当前账号）。"
            )
        enc_key = bytes.fromhex(info["enc_key"])
        wal = src + "-wal"
        db_mt = _mtime(src)
        wal_mt = _mtime(wal)
        prev = self._mtimes.get(rel)
        if dst.exists() and prev and prev[0] == db_mt and prev[1] == wal_mt:
            return dst
        t0 = time.time()
        descriptor, name = tempfile.mkstemp(prefix='.' + dst.name + '-', dir=dst.parent)
        os.close(descriptor)
        staged = Path(name)
        try:
            if dst.exists() and prev and prev[0] == db_mt and prev[1] != wal_mt:
                shutil.copyfile(dst, staged)
            else:
                crypto.decrypt_db_to_file(src, staged, enc_key)
            crypto.apply_wal(wal, staged, enc_key, bytes.fromhex(info['salt']))
            os.replace(staged, dst)
        finally:
            staged.unlink(missing_ok=True)
        self._mtimes[rel] = (db_mt, wal_mt)
        cost = time.time() - t0
        if cost > 1.0:
            logging.getLogger(__name__).info('Database refresh took %.1fs', cost)
        return dst

    def _connect(self, rel: str) -> sqlite3.Connection:
        path = self.refresh(rel)
        conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=5)
        conn.row_factory = sqlite3.Row
        conn.execute('PRAGMA temp_store=MEMORY')
        conn.execute('PRAGMA query_only=ON')
        return conn

    # ---------- 会话 / 联系人 ----------
    def sessions(self) -> dict[str, dict[str, Any]]:
        conn = self._connect("session/session.db")
        try:
            try:
                rows = conn.execute(
                    "SELECT username, unread_count, summary, last_timestamp, "
                    "last_msg_type, last_msg_sender, last_sender_display_name "
                    "FROM SessionTable WHERE last_timestamp > 0"
                ).fetchall()
            except sqlite3.OperationalError:
                rows = conn.execute("SELECT * FROM SessionTable").fetchall()
        finally:
            conn.close()
        out: dict[str, dict[str, Any]] = {}
        for row in rows:
            d = dict(row)
            username = d.get("username") or d.get("strUsername") or d.get("user_name")
            if not username:
                continue
            out[username] = {
                "unread": d.get("unread_count", 0) or 0,
                "summary": d.get("summary") or "",
                "timestamp": d.get("last_timestamp", 0) or 0,
                "msg_type": d.get("last_msg_type", 0) or 0,
                "sender": d.get("last_msg_sender") or "",
                "sender_name": d.get("last_sender_display_name") or "",
            }
        return out

    def contacts(self) -> dict[str, dict[str, str]]:
        conn = self._connect("contact/contact.db")
        try:
            rows = conn.execute("SELECT username, nick_name, remark FROM contact").fetchall()
        except sqlite3.OperationalError:
            rows = []
        finally:
            conn.close()
        out: dict[str, dict[str, str]] = {}
        for row in rows:
            d = dict(row)
            out[d.get("username") or ""] = {
                "nick_name": d.get("nick_name") or "",
                "remark": d.get("remark") or "",
            }
        return out

    def contact_directory(self, limit=20000):
        """Bounded contact/session metadata, without selecting message summaries."""
        if type(limit) is not int or not 1 <= limit <= 20000:
            raise ValueError('invalid_directory_limit')
        conn=self._connect('contact/contact.db')
        try:rows=conn.execute('SELECT username, nick_name, remark FROM contact LIMIT ?', (limit+1,)).fetchall()
        finally:conn.close()
        truncated=len(rows)>limit
        items={row['username']:dict(id=row['username'],nickname=row['nick_name'] or '',remark=row['remark'] or '',last_active=0)
               for row in rows[:limit] if row['username']}
        try:
            conn=self._connect('session/session.db')
            try:
                sessions=conn.execute('SELECT username, last_timestamp FROM SessionTable ORDER BY last_timestamp DESC LIMIT ?', (limit+1,)).fetchall()
            finally:conn.close()
            truncated=truncated or len(sessions)>limit
            for row in sessions[:limit]:
                uid=row['username']
                if not uid:continue
                item=items.setdefault(uid,dict(id=uid,nickname='',remark='',last_active=0))
                item['last_active']=row['last_timestamp'] or 0
        except (StoreError,sqlite3.Error):pass
        result=sorted(items.values(),key=lambda item: -item['last_active'])
        return dict(items=result[:limit],truncated=truncated or len(result)>limit)

    @staticmethod
    def display_name(contacts: dict[str, dict[str, str]], username: str, fallback: str = "") -> str:
        c = contacts.get(username)
        if c:
            return c.get("remark") or c.get("nick_name") or fallback or username
        return fallback or username

    def group_member_aliases(self, chat_id: str) -> dict[str, str]:
        """Current group display names, keyed by actual member username."""
        if not isinstance(chat_id, str) or not chat_id.endswith('@chatroom'):
            return {}
        from adapter_wc.messages.chatrooms import parse_member_aliases
        conn = self._connect('contact/contact.db')
        try:
            rows = conn.execute('SELECT ext_buffer FROM chat_room WHERE username=? LIMIT 2',
                                (chat_id,)).fetchall()
            if len(rows) != 1:
                return {}
            return parse_member_aliases(rows[0]['ext_buffer'])
        except sqlite3.OperationalError:
            return {}
        finally:
            conn.close()

    def avatar(self, username: str, *, max_bytes=524288) -> dict:
        """主进程按当前账号下的精确 username 读取头像缓存，不获取 URL。"""
        from adapter_wc.media.images import validate_image
        if not username or username.endswith("@chatroom"):
            return dict(available=False, error="avatar_invalid_member")
        conn = None
        try:
            conn = self._connect("head_image/head_image.db")
            rows = conn.execute("SELECT update_time, length(image_buffer) AS size, "
                "CASE WHEN length(image_buffer)<=? THEN image_buffer ELSE NULL END AS image "
                "FROM head_image WHERE username=? ORDER BY update_time DESC LIMIT 2", (max_bytes, username)).fetchall()
            if not rows:
                return dict(available=False, error="avatar_not_cached")
            if len(rows) == 2 and rows[0]["update_time"] == rows[1]["update_time"] and rows[0]["image"] != rows[1]["image"]:
                return dict(available=False, error="avatar_ambiguous")
            row = rows[0]
            if not row["size"] or row["size"] > max_bytes:
                return dict(available=False, error="avatar_size_limit")
            data = bytes(row["image"])
            mime, width, height = validate_image(data, max_bytes)
            if mime not in ("image/png", "image/jpeg", "image/webp") or max(width, height) > 2048:
                return dict(available=False, error="avatar_unsupported")
            return dict(available=True, data=data, mime=mime, width=width, height=height,
                        digest=hashlib.sha256(data).hexdigest(), observed_at=time.time())
        except (StoreError, sqlite3.Error, OSError, ValueError, TypeError):
            return dict(available=False, error="avatar_unavailable")
        finally:
            if conn is not None:
                conn.close()

    def resolve_chat(self, target: str) -> tuple[str, str]:
        """把群名/备注/wxid 解析成 (username, display_name)。"""
        target = (target or "").strip()
        if not target:
            raise StoreError('chat_identifier_required')
        if target.endswith("@chatroom") or target.startswith("wxid_") or target.startswith("gh_"):
            contacts = self.contacts()
            return target, self.display_name(contacts, target, target)

        contacts = self.contacts()
        # 精确匹配备注/昵称
        for username, c in contacts.items():
            if target in (c.get("remark"), c.get("nick_name")):
                return username, self.display_name(contacts, username, target)
        # 包含匹配
        matches = [
            (username, c)
            for username, c in contacts.items()
            if target in (c.get("remark") or "") or target in (c.get("nick_name") or "")
        ]
        if len(matches) == 1:
            username, _ = matches[0]
            return username, self.display_name(contacts, username, target)
        if len(matches) > 1:
            raise StoreError('ambiguous_chat')

        # 再从会话列表找
        for username in self.sessions():
            if username == target:
                return username, self.display_name(contacts, username, target)
        raise StoreError('chat_not_found')

    # ---------- 消息 ----------
    def _message_dbs(self) -> list[str]:
        root = os.path.join(self.db_dir, "message")
        try:
            names = [
                f"message/{n}"
                for n in os.listdir(root)
                if n.startswith("message_") and n.endswith(".db")
            ]
        except OSError:
            return []
        names.sort(key=lambda x: (x != "message/message_0.db", x))
        return names

    def message_table(self, chat_id: str) -> tuple[str, str]:
        """返回 (message DB rel, Msg_ 表名)。"""
        want = "Msg_" + hashlib.md5(chat_id.encode("utf-8")).hexdigest()
        dbs = self._message_dbs()
        for rel in dbs:
            try:
                conn = self._connect(rel)
                try:
                    row = conn.execute(
                        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
                        (want,),
                    ).fetchone()
                finally:
                    conn.close()
                if row:
                    return rel, want
            except (StoreError, sqlite3.DatabaseError):
                continue

        # 回退：用 Name2Id 反查
        for rel in dbs:
            try:
                conn = self._connect(rel)
                try:
                    rows = conn.execute("SELECT user_name FROM Name2Id").fetchall()
                except sqlite3.OperationalError:
                    rows = []
                finally:
                    conn.close()
                for row in rows:
                    username = row["user_name"] if isinstance(row, sqlite3.Row) else row[0]
                    if username == chat_id:
                        table = "Msg_" + hashlib.md5(username.encode("utf-8")).hexdigest()
                        return rel, table
            except (StoreError, sqlite3.DatabaseError):
                continue
        raise StoreError(
            f"在 message_*.db 里找不到 {chat_id} 的消息表。"
            "可能该群还没有本地消息，或微信版本改了表结构。"
        )

    def _decode_content(self, content: Any, ct: Any) -> str:
        if content is None:
            return ""
        if isinstance(content, memoryview):
            content = content.tobytes()
        if isinstance(content, bytes):
            if ct == 4:
                text = _decompress_zstd(content)
                if text is None:
                    return "[无法解压的消息]"
                return text
            try:
                return content.decode("utf-8", "replace")
            except Exception:
                return "[二进制消息]"
        return str(content)

    def _parse_message(
        self, chat_id: str, row: sqlite3.Row, contacts: dict, senders: dict | None = None
    ) -> dict[str, Any] | None:
        d = dict(row)
        local_id = d.get("local_id") or 0
        raw_type = int(d.get("local_type") or 0)
        local_type = raw_type & 0xFFFFFFFF
        create_time = d.get("create_time") or 0
        content = self._decode_content(
            d.get("message_content"), d.get("WCDB_CT_message_content")
        )
        source = self._decode_content(d.get('source'), d.get('WCDB_CT_source'))
        is_group = chat_id.endswith("@chatroom")
        sender = (senders or {}).get(d.get("real_sender_id"), "")
        text = content
        if is_group and ":\n" in content:
            prefix, body = content.split(":\n", 1)
            prefix = prefix.strip()
            if prefix == sender or (not sender and (prefix in contacts or prefix.startswith("wxid_"))):
                sender, text = prefix, body
        reference = None
        picture_md5 = image_md5(text) if local_type == 3 else ""
        message_kind = "text" if local_type == 1 else "image" if local_type == 3 else "non_text"
        pat = parse_pat(text, raw_type, chat_id) if local_type == 49 else None
        known = set(contacts) | set((senders or {}).values())
        if pat and (pat["actor"] not in known or pat["target"] not in known):
            pat = None
        if local_type == 49 and text:
            quoted = parse_quoted_reply(text, raw_type) if pat is None else None
            if pat is not None:
                sender, text, message_kind = pat["actor"], "", "pat"
            elif quoted is not None:
                text, reference = quoted
                message_kind = "quoted_text"
            else:
                text = _strip_xml_title(text)
        if local_type == 3:
            text = ""
        sender_name = self.display_name(contacts, sender, sender) if sender else ""
        if text is None:
            text = ""
        return {
            "local_id": int(local_id),
            "type": int(local_type),
            "raw_type": raw_type,
            "message_kind": message_kind,
            "reference": reference,
            **({"pat": pat, "pat_target_name": self.display_name(contacts, pat["target"], pat["target"])} if pat else {}),
            "image_md5": picture_md5,
            **({"image_cache_key": local_image_cache_key(d.get("packed_info_data"))} if local_type == 3 else {}),
            "server_id": str(d.get("server_id") or ""),
            "time": int(create_time),
            "time_source": "database",
            "sender": sender,
            "sender_name": sender_name,
            "text": text,
            "is_group": is_group,
            "mentioned_users": [] if pat else parse_mentioned_users(source) if is_group else [],
        }

    def _query_messages(
        self, chat_id: str, limit: int | None, after_local_id: int | None = None,
        time_window: tuple[int, int] | None = None,
        server_id: str | None = None,
        *, before: tuple[int, int] | None = None, max_local_id: int | None = None,
        page: bool = False, local_id: int | None = None,
    ) -> list[dict[str, Any]] | HistoryPage:
        rel, table = self.message_table(chat_id)
        contacts = self.contacts()
        conn = self._connect(rel)
        try:
            available = {r['name'] for r in conn.execute(f"PRAGMA table_info([{table}])")}
            cols = "rowid, local_id, local_type, create_time, message_content"
            for optional in ("WCDB_CT_message_content", "real_sender_id", "source", "WCDB_CT_source", "server_id", "packed_info_data"):
                if optional in available:
                    cols += ", " + optional
            senders = {}
            if "real_sender_id" in available:
                senders = {r['rowid']: r['user_name'] for r in conn.execute("SELECT rowid,user_name FROM Name2Id")}
            where = []
            params: list[Any] = []
            if local_id is not None:
                where.append('local_id = ?')
                params.append(local_id)
            if server_id is not None:
                if "server_id" not in available:
                    return []
                where.append("server_id = ?")
                params.append(server_id)
            if after_local_id is not None:
                where.append("local_id > ?")
                params.append(after_local_id)
            if time_window is not None:
                where.append("create_time >= ? AND create_time <= ?")
                params.extend(time_window)
            if before is not None:
                where.append('(create_time < ? OR (create_time = ? AND local_id < ?))')
                params.extend((before[0], before[0], before[1]))
            if max_local_id is not None:
                where.append('local_id <= ?')
                params.append(max_local_id)
            suffix = (" WHERE " + " AND ".join(where)) if where else ""
            suffix += (" ORDER BY local_id ASC" if after_local_id is not None
                       else " ORDER BY create_time DESC, local_id DESC")
            if limit is not None:
                suffix += " LIMIT ?"
                params.append(limit)
            rows = conn.execute(f"SELECT {cols} FROM [{table}]" + suffix, params).fetchall()
        finally:
            conn.close()
        parsed = [self._parse_message(chat_id, row, contacts, senders) for row in rows]
        parsed = [p for p in parsed if p is not None]
        if after_local_id is None:
            parsed.reverse()
        if page:
            cursor = min((int(r['create_time']), int(r['local_id'])) for r in rows) if rows else None
            return HistoryPage(parsed, len(rows), cursor)
        return parsed

    def _image_index_rows(self, digest, cache_key):
        conn = self._connect('hardlink/hardlink.db')
        prefix = ('SELECT i.file_name,d1.username AS bucket,d2.username AS month '
                  'FROM image_hardlink_info_v4 i LEFT JOIN dir2id d1 ON i.dir1=d1.rowid '
                  'LEFT JOIN dir2id d2 ON i.dir2=d2.rowid WHERE ')
        try:
            rows = conn.execute(prefix+'i.md5 IN (?,?,?) LIMIT 20',
                (digest, digest.encode('ascii'), bytes.fromhex(digest))).fetchall()
            if cache_key and re.fullmatch(r'[0-9a-f]{32}', cache_key):
                rows += conn.execute(prefix+'i.file_name IN (?,?,?) LIMIT 20',
                    (cache_key+'.dat', cache_key+'_h.dat', cache_key+'_t.dat')).fetchall()
            return rows
        finally:
            conn.close()

    def image_binding(self, chat_id: str, reference: dict) -> dict:
        """主进程查当前群消息及附件索引；仅返回本账号本地加密文件描述。"""
        binding = dict(account_root=str(Path(self.db_dir).parent), account=self.self_wxid,
                       home=str(Path.home()), candidates=[])
        digest = reference.get("image_md5") or ""
        server_id = str(reference.get("server_id") or "")
        proven = False
        cache_key = ""
        try:
            if reference.get("chat_id") and reference["chat_id"] != chat_id:
                return {**binding, "error": "image_reference_wrong_chat"}
            identifier = reference.get('local_id')
            direct = type(identifier) is int and identifier > 0
            if direct or re.fullmatch(r"[1-9][0-9]{0,19}", server_id):
                originals = self._query_messages(chat_id, 2, **(
                    dict(local_id=identifier) if direct else dict(server_id=server_id)))
                if direct and not originals:
                    return {**binding, 'error': 'image_reference_mismatch'}
                if originals:
                    if len(originals) != 1:
                        return {**binding, "error": "image_reference_mismatch"}
                    original = originals[0]
                    quoted_sender = reference.get('sender')
                    same_sender = not quoted_sender or original.get('sender') == quoted_sender
                    # Private-chat quote snapshots can name the other participant
                    # even when the exact source message belongs to this account.
                    private_source = (not chat_id.endswith('@chatroom') and not direct
                                      and bool(quoted_sender) and not same_sender
                                      and bool(digest) and digest == original.get('image_md5')
                                      and str(original.get('server_id') or '') == server_id)
                    if (original["type"] != 3 or not original.get("image_md5")
                            or (digest and digest != original["image_md5"])
                            or (direct and (original.get('local_id') != identifier
                                or original.get('time') != reference.get('time')))
                            or (not same_sender and not private_source)):
                        return {**binding, "error": "image_reference_mismatch"}
                    digest, proven = original["image_md5"], True
                    if type(original.get('local_id')) is int:
                        binding['source_message'] = {key: original.get(key) for key in
                            ('local_id', 'time', 'sender', 'server_id', 'image_md5')}
                    cache_key = original.get("image_cache_key") or ""
                    server_id = str(original.get('server_id') or server_id)
                    if (reference.get('sender') and original.get('sender') == reference['sender']
                            and re.fullmatch(r'[1-9][0-9]{0,19}', server_id)):
                        binding['download'] = dict(verified=True, server_id=server_id, chat_id=chat_id,
                                                   sender=original['sender'], image_md5=digest)
            if not re.fullmatch(r"[0-9a-f]{32}", digest):
                return {**binding, "error": "image_identifier_missing"}
            try:
                rows = self._image_index_rows(digest, cache_key if proven else '')
            except (StoreError, sqlite3.DatabaseError, OSError, ValueError):
                rows = []
                binding['index_error'] = 'local_image_index_unavailable'
            chat_hash = hashlib.md5(chat_id.encode()).hexdigest()
            for row in rows:
                filename, bucket, month = row["file_name"], row["bucket"], row["month"]
                if (not isinstance(filename, str) or not re.fullmatch(r"[0-9a-fA-F]{32}(?:_[ht])?\.dat", filename)
                        or not isinstance(bucket, str) or not re.fullmatch(r"[0-9a-fA-F]{32}", bucket)
                        or not isinstance(month, str) or not re.fullmatch(r"20[0-9]{2}-(?:0[1-9]|1[0-2])", month)
                        or (bucket.lower() != chat_hash and not proven)):
                    continue
                stem = re.sub(r"_[ht]$", "", filename[:-4])
                for item in _image_paths(bucket, month, chat_hash, stem):
                    if item not in binding["candidates"]:
                        binding["candidates"].append(item)
            # A thumbnail can exist before WeChat writes any hardlink index row.
            # Never use a cache key from the quote or infer a picture from proximity.
            if (proven and reference.get("sender") and (same_sender or private_source)
                    and re.fullmatch(r"[0-9a-f]{32}", cache_key)):
                known = {(c['relative'], c['quality']) for c in binding['candidates']}
                fallback = [dict(c, binding_source='verified_message_cache') for c in
                            _verified_image_paths(Path(binding['account_root']), chat_hash, cache_key)
                            if (c['relative'], c['quality']) not in known]
                if fallback:
                    binding['candidates'].extend(fallback)
                    binding["cache_fallback"] = True
            priority = {'original': 0, 'cached': 1, 'preview': 2, 'thumbnail': 3}
            binding['candidates'].sort(key=lambda c: priority[c['quality']])
            if not binding["candidates"]:
                binding["error"] = binding.get('index_error', 'local_image_index_missing')
        except (StoreError, sqlite3.DatabaseError, OSError, ValueError):
            binding["error"] = "local_image_index_unavailable"
        return binding

    def recent_messages(self, chat_id: str, limit: int = 20) -> list[dict[str, Any]]:
        return self._query_messages(chat_id, max(1, limit))

    def messages_before(self, chat_id, *, before, since, max_local_id, limit=200):
        if (not isinstance(before, tuple) or len(before) != 2
                or any(type(v) is not int or v < 1 for v in before)
                or type(since) is not int or since > before[0]
                or type(max_local_id) is not int or max_local_id < 1
                or type(limit) is not int or not 1 <= limit <= 200):
            raise StoreError('invalid_history_query')
        return self._query_messages(chat_id, limit, time_window=(since, before[0]),
                                    before=before, max_local_id=max_local_id, page=True)

    def messages_in_window(self, chat_id: str, start: int, end: int) -> list[dict[str, Any]]:
        if start > end or end <= 0:
            raise StoreError("无效的消息时间窗口")
        return self._query_messages(chat_id, None, time_window=(start, end))

    def messages_after(self, chat_id: str, after_local_id: int, limit: int = 50):
        return self._query_messages(chat_id, limit, after_local_id)

    def last_local_id(self, chat_id: str) -> int:
        rel, table = self.message_table(chat_id)
        conn = self._connect(rel)
        try:
            row = conn.execute(f"SELECT COALESCE(MAX(local_id), 0) FROM [{table}]").fetchone()
            return int(row[0]) if row else 0
        finally:
            conn.close()

    def session_of(self, chat_id: str) -> dict[str, Any] | None:
        return self.sessions().get(chat_id)

    def describe(self) -> str:
        lines = [
            f"数据目录: {self.db_dir}",
            f"当前账号: {self.self_wxid or '未知'}",
            f"密钥数量: {len(self.keys)}",
        ]
        try:
            sessions = self.sessions()
            lines.append(f"会话数量: {len(sessions)}")
        except Exception as exc:
            lines.append(f"会话读取失败: {exc}")
        return "\n".join(lines)


def format_time(ts: int) -> str:
    try:
        return datetime.fromtimestamp(ts).strftime("%m-%d %H:%M:%S")
    except (OSError, ValueError):
        return str(ts)
