"""Files and paths that installers copy or verify outside this package's Python environment.

The same data ships as ``adapter_wc/deployment.json`` so an installer can read it
straight from the wheel without importing or installing the package. Asset names
are relative to ``adapter_wc/native``; other paths are relative to ``adapter_wc``.
"""
import json
from importlib.resources import files

_DATA = json.loads(files(__package__).joinpath('deployment.json').read_text(encoding='utf-8'))

HELPER_ASSETS = tuple(_DATA['helper_assets'])
IMAGE_ASSETS = tuple(_DATA['image_assets'])
NATIVE_PROFILE = _DATA['native_profile']
IMAGE_RUNTIME_DIRECTORY = _DATA['image_runtime_directory']
RECOVERY_MODULES = tuple(_DATA['recovery_modules'])

__all__ = ['HELPER_ASSETS', 'IMAGE_ASSETS', 'NATIVE_PROFILE', 'IMAGE_RUNTIME_DIRECTORY', 'RECOVERY_MODULES']
