"""Reusable Linux WeChat adapter. No model configuration or implicit I/O on import."""
from adapter_wc.models import DeliveryState,Image,Message,MessageBatch,SendReceipt
from adapter_wc.errors import WeChatError,NativeError,OwnerBusyError,SendError,StoreError,MediaError,DependencyError,ImageDownloadError

__version__='0.4.2'
__all__=['WeChatSession','SessionConfig','NativeSender','DeliveryState','Image','Message',
         'MessageBatch','SendReceipt','WeChatError','NativeError','OwnerBusyError','SendError','StoreError','MediaError',
         'DependencyError','capabilities','NativeImageDownloader','ImageDownloadError','NativeOptions',
         'LoginController','LoginStatus','LoginQRCode','LoginError']


def __getattr__(name):
    if name in ('LoginController','LoginStatus','LoginQRCode','LoginError'):
        from adapter_wc.desktop import login
        return getattr(login,name)
    if name in ('WeChatSession','SessionConfig'):
        from adapter_wc import session
        return getattr(session,name)
    if name=='NativeSender':
        from adapter_wc.native.sender import NativeSender
        return NativeSender
    if name=='NativeOptions':
        from adapter_wc.native.options import NativeOptions
        return NativeOptions
    if name=='NativeImageDownloader':
        from adapter_wc.native.image_download import NativeImageDownloader
        return NativeImageDownloader
    if name=='capabilities':
        from adapter_wc.profiles import capabilities
        return capabilities
    raise AttributeError(name)
